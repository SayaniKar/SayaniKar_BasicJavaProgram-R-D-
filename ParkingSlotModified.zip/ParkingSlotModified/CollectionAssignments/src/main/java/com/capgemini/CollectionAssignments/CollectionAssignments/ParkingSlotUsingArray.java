package com.capgemini.CollectionAssignments.CollectionAssignments;

public class ParkingSlotUsingArray {

	int[] floor=new int[4];
	int i;int j;
	public void addSections()
	{ System.out.println("Add Sections");
	for( i=0;i<4;i++)
	{
		int[][] sections=new int[i][4];
		
	}
	}
	public void addCompartments()
	{
	System.out.println("Enter the Number of compartments");
	{
		for(i=0;i<4;i++)
		{
			for(j=0;j<4;j++)
			{
				int[][][] compartments=new int[i][j][10];
			}
		}
	}
	
}
	/*public ParkingusingArray[] addCars(CustomerusingArray customer)
	{
	   
	}*/


	public static void main(String[] args) {
		// TODO Auto-generated method stub
	{
		
	}
	}
}


	



