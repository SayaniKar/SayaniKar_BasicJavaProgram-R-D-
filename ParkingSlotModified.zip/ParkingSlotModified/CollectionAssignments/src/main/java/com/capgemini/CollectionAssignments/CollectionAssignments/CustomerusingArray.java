package com.capgemini.CollectionAssignments.CollectionAssignments;

public class CustomerusingArray {
	String customerName;
	ParkingusingArray parking1;
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public ParkingusingArray getPark1() {
		return parking1;
	}
	public void setPark1(ParkingusingArray parking1) {
		this.parking1 = parking1;
	}
	@Override
	public String toString() {
		return "CustomerusingArray [customerName=" + customerName + ", parking1=" + parking1 + "]";
	}
	

}
