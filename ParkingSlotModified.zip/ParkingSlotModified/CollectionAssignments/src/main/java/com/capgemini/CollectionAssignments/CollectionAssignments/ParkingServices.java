package com.capgemini.CollectionAssignments.CollectionAssignments;


import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.*;

public class ParkingServices {
	
	
	List<List<Map<Parking, Customer>>> parkingBuilding=new ArrayList<>(4);
	 int floor=0;
      int section=0;
	 int compartment=0;
	
	public ParkingServices() {
		for(int floorIndex=0;floorIndex<4;floorIndex++)
			parkingBuilding.add(new ArrayList<Map<Parking,Customer>>(4));
		
		for(int floorIndex=0;floorIndex<4;floorIndex++)
		{
			for(int sectionIndex=0;sectionIndex<4;sectionIndex++)
			{
				parkingBuilding.get(floorIndex).add(new HashMap<Parking,Customer>(10));
			}
		}
			
		
	}

	public Parking addCarParking(Customer cust)
	{
		if(parkingBuilding.get(floor).get(section).size()==10)
		{
			section++;
			compartment=0;
		}
		if(section==4)
		{
			floor++;
			section=0;
			compartment=0;
		}
		if(floor==4)
			throw new RuntimeException("Only 4 Floors are Available");
		Parking parking=new Parking(floor,section,compartment++);
		parkingBuilding.get(floor).get(section).put(parking,cust);
			
		
		return parking;
		
	}
	
	public Customer getAllDetailsOfCar(Parking parking)
	{
		parking.setFloor(parking.getFloor()-1);
		parking.setSection(parking.getSection()-1);
		parking.setCompartment(parking.getCompartment()-1);
		Customer cust=parkingBuilding.get(parking.getFloor()).get(parking.getSection()).get(parking);
		return cust;
		
	}
	/*public Customer RemoveCar(Parking parking)
	{
	
			Customer cust1=parkingBuilding.remove(parking);
	
return 
	}*/

	
	public static void main(String[] args)
	{
		ParkingServices parkingMap=new ParkingServices();
		LocalTime time = LocalTime.now();
		Customer customer =new Customer("Akash", "912345678",time.toString());
		Parking park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 time = LocalTime.now();
		 customer =new Customer("Barun", "8943250988",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		customer =new Customer("Meghna", "8943330990",time.toString());
		park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 customer =new Customer("Ranjita", "8911094444",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 customer =new Customer("Ritu", "9095808357",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 customer =new Customer("Abhi", "998987654",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 customer =new Customer("Rahul", "90978654",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 customer =new Customer("Rikoki", "9089875654",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 customer =new Customer("Helly", "9999652999",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 customer =new Customer("Hiran", "909867547",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		 customer =new Customer("Ribhu", "9810101066",time.toString());
		 park=parkingMap.addCarParking(customer);
		System.out.println(park+" "+customer);
		
		System.out.println("\nGet customer details by Id:");
		Parking park1=new Parking(1, 1, 5);
		System.out.println(parkingMap.getAllDetailsOfCar(park1));
		//System.out.println("Remove by a paricular ID");
		//parkingMap.RemoveCar(park1);
	}
	

}
