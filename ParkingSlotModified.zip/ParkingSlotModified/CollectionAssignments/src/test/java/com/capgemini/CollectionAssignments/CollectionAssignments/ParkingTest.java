package com.capgemini.CollectionAssignments.CollectionAssignments;

import java.time.LocalTime;

import org.junit.Assert;
import org.junit.Test;


public class ParkingTest {
	@Test
	public void addCarParking()
	{
		ParkingServices parkingService=new ParkingServices();
		LocalTime time = LocalTime.now();
		Customer customer =new Customer("Sayani", "9123456789",time.toString());
		Assert.assertEquals(new Parking(0, 0, 0),parkingService.addCarParking(customer));
	}

}
